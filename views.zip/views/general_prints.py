# coding=utf-8

"""
File listing all possible prints/displays
"""
# à scinder surement ensuite !


# Prints Player
class PlayerDisplay:
    def __init__(self):
        pass






# Prints Tournament
class TournamentDisplay:
    def __init__(self):
        pass
